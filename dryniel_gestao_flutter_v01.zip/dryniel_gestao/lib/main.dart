import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';

const navy = Color(0xFF1E2C59);
const taupe = Color(0xFF9B8F7B);
const background = Color(0xFFF5F6F8);

final money = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$', decimalDigits: 2);
final dateFmt = DateFormat('dd/MM/yyyy');

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.load();
  runApp(DrynielApp(store: store));
}

class DrynielApp extends StatelessWidget {
  const DrynielApp({super.key, required this.store});
  final AppStore store;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DRYNIEL Gestão',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: background,
        colorScheme: ColorScheme.fromSeed(seedColor: navy, primary: navy, secondary: taupe),
        appBarTheme: const AppBarTheme(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE1E4EA))),
        ),
      ),
      home: AppShell(store: store),
    );
  }
}

class Budget {
  Budget({required this.id, required this.client, required this.phone, required this.address, required this.description, required this.value, required this.date, this.approved = false});
  final String id;
  String client;
  String phone;
  String address;
  String description;
  double value;
  DateTime date;
  bool approved;

  Map<String, dynamic> toJson() => {
        'id': id,
        'client': client,
        'phone': phone,
        'address': address,
        'description': description,
        'value': value,
        'date': date.toIso8601String(),
        'approved': approved,
      };

  factory Budget.fromJson(Map<String, dynamic> j) => Budget(
        id: j['id'],
        client: j['client'] ?? '',
        phone: j['phone'] ?? '',
        address: j['address'] ?? '',
        description: j['description'] ?? '',
        value: (j['value'] ?? 0).toDouble(),
        date: DateTime.tryParse(j['date'] ?? '') ?? DateTime.now(),
        approved: j['approved'] ?? false,
      );
}

class Expense {
  Expense({required this.id, required this.work, required this.category, required this.description, required this.value, required this.date});
  final String id;
  String work;
  String category;
  String description;
  double value;
  DateTime date;

  Map<String, dynamic> toJson() => {'id': id, 'work': work, 'category': category, 'description': description, 'value': value, 'date': date.toIso8601String()};
  factory Expense.fromJson(Map<String, dynamic> j) => Expense(id: j['id'], work: j['work'] ?? '', category: j['category'] ?? 'Outros', description: j['description'] ?? '', value: (j['value'] ?? 0).toDouble(), date: DateTime.tryParse(j['date'] ?? '') ?? DateTime.now());
}

class DailyEntry {
  DailyEntry({required this.id, required this.employee, required this.role, required this.work, required this.value, required this.date});
  final String id;
  String employee;
  String role;
  String work;
  double value;
  DateTime date;

  Map<String, dynamic> toJson() => {'id': id, 'employee': employee, 'role': role, 'work': work, 'value': value, 'date': date.toIso8601String()};
  factory DailyEntry.fromJson(Map<String, dynamic> j) => DailyEntry(id: j['id'], employee: j['employee'] ?? '', role: j['role'] ?? '', work: j['work'] ?? '', value: (j['value'] ?? 0).toDouble(), date: DateTime.tryParse(j['date'] ?? '') ?? DateTime.now());
}

class AppStore extends ChangeNotifier {
  static const _key = 'dryniel_data_v1';
  final budgets = <Budget>[];
  final expenses = <Expense>[];
  final dailies = <DailyEntry>[];

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) {
      _seed();
      await save();
      return;
    }
    try {
      final data = jsonDecode(raw) as Map<String, dynamic>;
      budgets.addAll((data['budgets'] as List? ?? []).map((e) => Budget.fromJson(Map<String, dynamic>.from(e))));
      expenses.addAll((data['expenses'] as List? ?? []).map((e) => Expense.fromJson(Map<String, dynamic>.from(e))));
      dailies.addAll((data['dailies'] as List? ?? []).map((e) => DailyEntry.fromJson(Map<String, dynamic>.from(e))));
    } catch (_) {
      budgets.clear(); expenses.clear(); dailies.clear(); _seed();
    }
  }

  void _seed() {
    budgets.add(Budget(
      id: 'b1',
      client: 'Igreja Adventista da Promessa',
      phone: '',
      address: 'Rua Alonso de Vasconcelos Pacheco, 2121 — Vila Falchi, Mauá/SP',
      description: 'Instalação de forro drywall (68 m²) e pintura do forro instalado.',
      value: 8153,
      date: DateTime(2026, 9, 4),
      approved: true,
    ));
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode({
      'budgets': budgets.map((e) => e.toJson()).toList(),
      'expenses': expenses.map((e) => e.toJson()).toList(),
      'dailies': dailies.map((e) => e.toJson()).toList(),
    }));
  }

  Future<void> addBudget(Budget b) async { budgets.insert(0, b); notifyListeners(); await save(); }
  Future<void> addExpense(Expense e) async { expenses.insert(0, e); notifyListeners(); await save(); }
  Future<void> addDaily(DailyEntry d) async { dailies.insert(0, d); notifyListeners(); await save(); }
  Future<void> toggleApproved(Budget b) async { b.approved = !b.approved; notifyListeners(); await save(); }

  double get revenue => budgets.where((b) => b.approved).fold(0, (a, b) => a + b.value);
  double get expenseTotal => expenses.fold(0, (a, b) => a + b.value);
  double get dailyTotal => dailies.fold(0, (a, b) => a + b.value);
  double get profit => revenue - expenseTotal - dailyTotal;

  double expensesFor(String work) => expenses.where((e) => e.work == work).fold(0, (a, b) => a + b.value);
  double dailiesFor(String work) => dailies.where((e) => e.work == work).fold(0, (a, b) => a + b.value);
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.store});
  final AppStore store;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.store,
      builder: (_, __) {
        final screens = [
          HomePage(store: widget.store, onOpen: (i) => setState(() => index = i)),
          WorksPage(store: widget.store),
          ExpensesPage(store: widget.store),
          EmployeesPage(store: widget.store),
          FinancePage(store: widget.store),
        ];
        return Scaffold(
          body: screens[index],
          bottomNavigationBar: NavigationBar(
            selectedIndex: index,
            onDestinationSelected: (i) => setState(() => index = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Início'),
              NavigationDestination(icon: Icon(Icons.construction_outlined), selectedIcon: Icon(Icons.construction), label: 'Obras'),
              NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Gastos'),
              NavigationDestination(icon: Icon(Icons.groups_outlined), selectedIcon: Icon(Icons.groups), label: 'Diárias'),
              NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Financeiro'),
            ],
          ),
        );
      },
    );
  }
}

class BrandHeader extends StatelessWidget implements PreferredSizeWidget {
  const BrandHeader({super.key, this.title});
  final String? title;
  @override
  Size get preferredSize => const Size.fromHeight(82);
  @override
  Widget build(BuildContext context) {
    return AppBar(
      toolbarHeight: 82,
      title: Row(children: [
        Image.asset('assets/logo_dryniel.png', height: 46, width: 145, fit: BoxFit.cover, alignment: Alignment.centerLeft),
        if (title != null) ...[
          const SizedBox(width: 12),
          Container(width: 1, height: 32, color: Colors.white24),
          const SizedBox(width: 12),
          Expanded(child: Text(title!, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
        ]
      ]),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.store, required this.onOpen});
  final AppStore store;
  final ValueChanged<int> onOpen;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const BrandHeader(),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Visão geral', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: navy)),
          const SizedBox(height: 4),
          Text(DateFormat("MMMM 'de' yyyy", 'pt_BR').format(DateTime.now()), style: TextStyle(color: Colors.grey.shade600)),
          const SizedBox(height: 16),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            childAspectRatio: 1.55,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            children: [
              MetricCard(label: 'Faturamento', value: money.format(store.revenue), icon: Icons.trending_up, accent: Colors.green),
              MetricCard(label: 'Gastos', value: money.format(store.expenseTotal), icon: Icons.shopping_cart_outlined, accent: Colors.red),
              MetricCard(label: 'Diárias', value: money.format(store.dailyTotal), icon: Icons.groups, accent: Colors.blue),
              MetricCard(label: 'Lucro estimado', value: money.format(store.profit), icon: Icons.query_stats, accent: taupe),
            ],
          ),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewBudgetPage(store: store))), icon: const Icon(Icons.add), label: const Text('Novo orçamento'))),
          ]),
          const SizedBox(height: 14),
          const Text('Acesso rápido', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            QuickAction(icon: Icons.construction, label: 'Obras', onTap: () => onOpen(1)),
            QuickAction(icon: Icons.receipt_long, label: 'Novo gasto', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewExpensePage(store: store)))),
            QuickAction(icon: Icons.groups, label: 'Nova diária', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewDailyPage(store: store)))),
            QuickAction(icon: Icons.bar_chart, label: 'Financeiro', onTap: () => onOpen(4)),
          ]),
          const SizedBox(height: 18),
          const Text('Orçamentos recentes', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          ...store.budgets.take(4).map((b) => BudgetTile(store: store, budget: b)),
        ],
      ),
    );
  }
}

class MetricCard extends StatelessWidget {
  const MetricCard({super.key, required this.label, required this.value, required this.icon, required this.accent});
  final String label, value;
  final IconData icon;
  final Color accent;
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(label, style: TextStyle(color: Colors.grey.shade700, fontWeight: FontWeight.w600)), Icon(icon, color: accent)]),
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: navy)),
      ]),
    ),
  );
}

class QuickAction extends StatelessWidget {
  const QuickAction({super.key, required this.icon, required this.label, required this.onTap});
  final IconData icon; final String label; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => ActionChip(avatar: Icon(icon, size: 18, color: navy), label: Text(label), onPressed: onTap, backgroundColor: Colors.white, side: const BorderSide(color: Color(0xFFE1E4EA)));
}

class WorksPage extends StatelessWidget {
  const WorksPage({super.key, required this.store});
  final AppStore store;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: const BrandHeader(title: 'Obras'),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Obras e orçamentos', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: navy)),
      const SizedBox(height: 12),
      if (store.budgets.isEmpty) const EmptyState(icon: Icons.description_outlined, text: 'Nenhum orçamento cadastrado.'),
      ...store.budgets.map((b) => BudgetTile(store: store, budget: b)),
    ]),
    floatingActionButton: FloatingActionButton.extended(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewBudgetPage(store: store))), icon: const Icon(Icons.add), label: const Text('Orçamento')),
  );
}

class BudgetTile extends StatelessWidget {
  const BudgetTile({super.key, required this.store, required this.budget});
  final AppStore store; final Budget budget;
  @override
  Widget build(BuildContext context) {
    final costs = store.expensesFor(budget.client) + store.dailiesFor(budget.client);
    return Card(child: ListTile(
      contentPadding: const EdgeInsets.all(14),
      title: Text(budget.client, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Padding(padding: const EdgeInsets.only(top: 6), child: Text('${dateFmt.format(budget.date)} • Custos: ${money.format(costs)}\n${budget.approved ? 'Obra aprovada' : 'Orçamento pendente'}')),
      trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text(money.format(budget.value), style: const TextStyle(fontWeight: FontWeight.w800, color: navy)),
        const SizedBox(height: 5),
        Icon(budget.approved ? Icons.check_circle : Icons.schedule, size: 20, color: budget.approved ? Colors.green : Colors.orange),
      ]),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WorkDetailPage(store: store, budget: budget))),
    ));
  }
}

class WorkDetailPage extends StatelessWidget {
  const WorkDetailPage({super.key, required this.store, required this.budget});
  final AppStore store; final Budget budget;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(animation: store, builder: (_, __) {
    final exp = store.expensesFor(budget.client); final dia = store.dailiesFor(budget.client); final result = budget.value - exp - dia;
    return Scaffold(
      appBar: AppBar(title: Text(budget.client)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Chip(label: Text(budget.approved ? 'Em andamento / aprovada' : 'Orçamento pendente'), avatar: Icon(budget.approved ? Icons.check : Icons.schedule, size: 18)),
          const Spacer(),
          TextButton(onPressed: () => store.toggleApproved(budget), child: Text(budget.approved ? 'Marcar pendente' : 'Aprovar')),
        ]),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(budget.address, style: TextStyle(color: Colors.grey.shade700)), const SizedBox(height: 8), Text(budget.description),
        ]))),
        const SizedBox(height: 10),
        GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 1.6, crossAxisSpacing: 8, mainAxisSpacing: 8, children: [
          MetricCard(label: 'Orçamento', value: money.format(budget.value), icon: Icons.description, accent: navy),
          MetricCard(label: 'Gastos', value: money.format(exp), icon: Icons.receipt_long, accent: Colors.red),
          MetricCard(label: 'Diárias', value: money.format(dia), icon: Icons.groups, accent: Colors.blue),
          MetricCard(label: 'Resultado', value: money.format(result), icon: Icons.query_stats, accent: result >= 0 ? Colors.green : Colors.red),
        ]),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: () => PdfService.previewBudget(context, budget), icon: const Icon(Icons.picture_as_pdf), label: const Text('Visualizar orçamento em PDF')),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewExpensePage(store: store, presetWork: budget.client))), icon: const Icon(Icons.add_card), label: const Text('Adicionar gasto')),
        OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewDailyPage(store: store, presetWork: budget.client))), icon: const Icon(Icons.person_add_alt_1), label: const Text('Adicionar diária')),
      ]),
    );
  });
}

class ExpensesPage extends StatelessWidget {
  const ExpensesPage({super.key, required this.store}); final AppStore store;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: const BrandHeader(title: 'Gastos'),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Despesas', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: navy)),
        Text(money.format(store.expenseTotal), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.red)),
      ]),
      const SizedBox(height: 12),
      if (store.expenses.isEmpty) const EmptyState(icon: Icons.receipt_long_outlined, text: 'Nenhum gasto lançado ainda.'),
      ...store.expenses.map((e) => Card(child: ListTile(
        leading: CircleAvatar(backgroundColor: navy.withValues(alpha: .08), child: Icon(_expenseIcon(e.category), color: navy)),
        title: Text(e.category, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text('${e.description}\n${e.work} • ${dateFmt.format(e.date)}'),
        isThreeLine: true,
        trailing: Text(money.format(e.value), style: const TextStyle(fontWeight: FontWeight.w800)),
      ))),
    ]),
    floatingActionButton: FloatingActionButton.extended(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewExpensePage(store: store))), icon: const Icon(Icons.add), label: const Text('Novo gasto')),
  );
}

IconData _expenseIcon(String c) => switch (c) {
  'Combustível' => Icons.local_gas_station,
  'Alimentação' => Icons.restaurant,
  'Ferramentas' => Icons.handyman,
  'Materiais' => Icons.inventory_2,
  'Transporte' => Icons.local_shipping,
  _ => Icons.more_horiz,
};

class EmployeesPage extends StatelessWidget {
  const EmployeesPage({super.key, required this.store}); final AppStore store;
  @override
  Widget build(BuildContext context) {
    final grouped = <String, double>{};
    for (final d in store.dailies) { grouped[d.employee] = (grouped[d.employee] ?? 0) + d.value; }
    return Scaffold(
      appBar: const BrandHeader(title: 'Funcionários'),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Diárias', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: navy)), Text(money.format(store.dailyTotal), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.blue))]),
        const SizedBox(height: 12),
        if (grouped.isNotEmpty) ...[
          const Text('Total por funcionário', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 6),
          ...grouped.entries.map((e) => Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(e.key), trailing: Text(money.format(e.value), style: const TextStyle(fontWeight: FontWeight.w800))))),
          const SizedBox(height: 10),
        ],
        const Text('Últimos lançamentos', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        if (store.dailies.isEmpty) const EmptyState(icon: Icons.groups_outlined, text: 'Nenhuma diária lançada ainda.'),
        ...store.dailies.map((d) => Card(child: ListTile(
          title: Text(d.employee, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('${d.role.isEmpty ? 'Funcionário' : d.role}\n${d.work} • ${dateFmt.format(d.date)}'),
          isThreeLine: true,
          trailing: Text(money.format(d.value), style: const TextStyle(fontWeight: FontWeight.w800)),
        ))),
      ]),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewDailyPage(store: store))), icon: const Icon(Icons.add), label: const Text('Nova diária')),
    );
  }
}

class FinancePage extends StatelessWidget {
  const FinancePage({super.key, required this.store}); final AppStore store;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: const BrandHeader(title: 'Financeiro'),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Resultado geral', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: navy)),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        FinanceRow(label: 'Faturamento aprovado', value: store.revenue, color: Colors.green),
        FinanceRow(label: 'Gastos', value: -store.expenseTotal, color: Colors.red),
        FinanceRow(label: 'Diárias', value: -store.dailyTotal, color: Colors.red),
        const Divider(height: 28),
        FinanceRow(label: 'Lucro estimado', value: store.profit, color: store.profit >= 0 ? navy : Colors.red, strong: true),
      ]))),
      const SizedBox(height: 16),
      const Text('Resultado por obra', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)), const SizedBox(height: 8),
      ...store.budgets.where((b) => b.approved).map((b) {
        final result = b.value - store.expensesFor(b.client) - store.dailiesFor(b.client);
        return Card(child: ListTile(title: Text(b.client), subtitle: Text('Contrato: ${money.format(b.value)}'), trailing: Text(money.format(result), style: TextStyle(fontWeight: FontWeight.w800, color: result >= 0 ? Colors.green : Colors.red))));
      }),
    ]),
  );
}

class FinanceRow extends StatelessWidget {
  const FinanceRow({super.key, required this.label, required this.value, required this.color, this.strong = false});
  final String label; final double value; final Color color; final bool strong;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(children: [Expanded(child: Text(label, style: TextStyle(fontWeight: strong ? FontWeight.w800 : FontWeight.w500))), Text(money.format(value), style: TextStyle(fontSize: strong ? 20 : 16, fontWeight: FontWeight.w800, color: color))]));
}

class NewBudgetPage extends StatefulWidget {
  const NewBudgetPage({super.key, required this.store}); final AppStore store;
  @override State<NewBudgetPage> createState() => _NewBudgetPageState();
}

class _NewBudgetPageState extends State<NewBudgetPage> {
  final form = GlobalKey<FormState>();
  final client = TextEditingController(), phone = TextEditingController(), address = TextEditingController(), description = TextEditingController(), value = TextEditingController();
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Novo orçamento')),
    body: Form(key: form, child: ListView(padding: const EdgeInsets.all(16), children: [
      field(client, 'Cliente', required: true), field(phone, 'Telefone'), field(address, 'Endereço'), field(description, 'Descrição dos serviços', maxLines: 5, required: true), field(value, 'Valor total (R\$)', keyboard: TextInputType.number, required: true),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Salvar orçamento')),
    ])),
  );
  Future<void> _save() async {
    if (!form.currentState!.validate()) return;
    final parsed = double.tryParse(value.text.replaceAll('.', '').replaceAll(',', '.')) ?? 0;
    await widget.store.addBudget(Budget(id: DateTime.now().microsecondsSinceEpoch.toString(), client: client.text.trim(), phone: phone.text.trim(), address: address.text.trim(), description: description.text.trim(), value: parsed, date: DateTime.now()));
    if (mounted) Navigator.pop(context);
  }
}

class NewExpensePage extends StatefulWidget {
  const NewExpensePage({super.key, required this.store, this.presetWork}); final AppStore store; final String? presetWork;
  @override State<NewExpensePage> createState() => _NewExpensePageState();
}

class _NewExpensePageState extends State<NewExpensePage> {
  final form = GlobalKey<FormState>(); late final TextEditingController work; final description = TextEditingController(), value = TextEditingController(); String category = 'Combustível';
  static const categories = ['Combustível', 'Alimentação', 'Ferramentas', 'Materiais', 'Transporte', 'Hospedagem', 'Outros'];
  @override void initState(){ super.initState(); work = TextEditingController(text: widget.presetWork ?? ''); }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Novo gasto')), body: Form(key: form, child: ListView(padding: const EdgeInsets.all(16), children: [
    field(work, 'Obra / cliente', required: true),
    DropdownButtonFormField<String>(initialValue: category, decoration: const InputDecoration(labelText: 'Categoria'), items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(), onChanged: (v) => setState(() => category = v!)),
    const SizedBox(height: 12), field(description, 'Descrição', required: true), field(value, 'Valor (R\$)', keyboard: TextInputType.number, required: true),
    const SizedBox(height: 12), FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Salvar gasto')),
  ])));
  Future<void> _save() async { if(!form.currentState!.validate()) return; final parsed=double.tryParse(value.text.replaceAll('.', '').replaceAll(',', '.'))??0; await widget.store.addExpense(Expense(id: DateTime.now().microsecondsSinceEpoch.toString(), work: work.text.trim(), category: category, description: description.text.trim(), value: parsed, date: DateTime.now())); if(mounted) Navigator.pop(context); }
}

class NewDailyPage extends StatefulWidget {
  const NewDailyPage({super.key, required this.store, this.presetWork}); final AppStore store; final String? presetWork;
  @override State<NewDailyPage> createState() => _NewDailyPageState();
}

class _NewDailyPageState extends State<NewDailyPage> {
  final form = GlobalKey<FormState>(); final employee=TextEditingController(), role=TextEditingController(), value=TextEditingController(); late final TextEditingController work;
  @override void initState(){ super.initState(); work=TextEditingController(text: widget.presetWork ?? ''); }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Nova diária')), body: Form(key: form, child: ListView(padding: const EdgeInsets.all(16), children: [
    field(employee, 'Funcionário', required: true), field(role, 'Função (ex.: montador, ajudante)'), field(work, 'Obra / cliente', required: true), field(value, 'Valor da diária (R\$)', keyboard: TextInputType.number, required: true),
    const SizedBox(height: 12), FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Salvar diária')),
  ])));
  Future<void> _save() async { if(!form.currentState!.validate()) return; final parsed=double.tryParse(value.text.replaceAll('.', '').replaceAll(',', '.'))??0; await widget.store.addDaily(DailyEntry(id: DateTime.now().microsecondsSinceEpoch.toString(), employee: employee.text.trim(), role: role.text.trim(), work: work.text.trim(), value: parsed, date: DateTime.now())); if(mounted) Navigator.pop(context); }
}

Widget field(TextEditingController c, String label, {bool required=false, int maxLines=1, TextInputType? keyboard}) => Padding(
  padding: const EdgeInsets.only(bottom: 12),
  child: TextFormField(controller: c, maxLines: maxLines, keyboardType: keyboard, decoration: InputDecoration(labelText: label), validator: (v) => required && (v == null || v.trim().isEmpty) ? 'Preencha este campo' : null),
);

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.text}); final IconData icon; final String text;
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 40), child: Column(children: [Icon(icon, size: 48, color: Colors.grey.shade400), const SizedBox(height: 8), Text(text, style: TextStyle(color: Colors.grey.shade600))]));
}

class PdfService {
  static Future<Uint8List> buildBudget(Budget b) async {
    final doc = pw.Document();
    final logoBytes = (await rootBundle.load('assets/logo_dryniel.png')).buffer.asUint8List();
    final logo = pw.MemoryImage(logoBytes);
    final font = await PdfGoogleFonts.robotoRegular();
    final bold = await PdfGoogleFonts.robotoBold();
    final blue = PdfColor.fromHex('#1E2C59');
    final beige = PdfColor.fromHex('#9B8F7B');
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(36),
      theme: pw.ThemeData.withFont(base: font, bold: bold),
      header: (_) => pw.Column(children: [
        pw.Container(height: 72, width: double.infinity, color: blue, padding: const pw.EdgeInsets.all(10), child: pw.Align(alignment: pw.Alignment.centerLeft, child: pw.Image(logo, fit: pw.BoxFit.contain))),
        pw.SizedBox(height: 14),
      ]),
      build: (_) => [
        pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [pw.Text('ORÇAMENTO', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold, color: blue)), pw.Text(dateFmt.format(b.date))]),
        pw.SizedBox(height: 18),
        pw.Container(padding: const pw.EdgeInsets.all(12), decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey300), borderRadius: pw.BorderRadius.circular(6)), child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          _pdfLine('CLIENTE', b.client, bold, blue),
          if (b.phone.isNotEmpty) _pdfLine('TELEFONE', b.phone, bold, blue),
          if (b.address.isNotEmpty) _pdfLine('ENDEREÇO DA OBRA', b.address, bold, blue),
        ])),
        pw.SizedBox(height: 18),
        pw.Container(color: blue, padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 7), child: pw.Row(children: [pw.Expanded(child: pw.Text('SERVIÇOS', style: pw.TextStyle(color: PdfColors.white, fontWeight: pw.FontWeight.bold))), pw.Text('VALOR', style: pw.TextStyle(color: PdfColors.white, fontWeight: pw.FontWeight.bold))])),
        pw.Container(padding: const pw.EdgeInsets.all(12), decoration: const pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(color: PdfColors.grey300), left: pw.BorderSide(color: PdfColors.grey300), right: pw.BorderSide(color: PdfColors.grey300))), child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [pw.Expanded(child: pw.Text(b.description)), pw.SizedBox(width: 15), pw.Text(money.format(b.value), style: pw.TextStyle(fontWeight: pw.FontWeight.bold))])),
        pw.SizedBox(height: 14),
        pw.Align(alignment: pw.Alignment.centerRight, child: pw.Container(color: beige, padding: const pw.EdgeInsets.symmetric(horizontal: 16, vertical: 10), child: pw.Text('TOTAL  ${money.format(b.value)}', style: pw.TextStyle(color: PdfColors.white, fontSize: 15, fontWeight: pw.FontWeight.bold)))),
        pw.SizedBox(height: 28),
        pw.Text('OBSERVAÇÕES', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: blue)),
        pw.SizedBox(height: 6),
        pw.Text('Valores apresentados conforme os serviços descritos neste orçamento. Condições de pagamento e prazo de execução a combinar.'),
      ],
      footer: (_) => pw.Column(children: [pw.Divider(color: beige), pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [pw.Text('DRYNIEL Construção a Seco', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: blue)), pw.Text('(11) 95832-5981 • @dryniel.br • Mauá/SP')])]),
    ));
    return doc.save();
  }

  static pw.Widget _pdfLine(String label, String value, pw.Font bold, PdfColor blue) => pw.Padding(padding: const pw.EdgeInsets.only(bottom: 7), child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [pw.Text(label, style: pw.TextStyle(font: bold, fontSize: 8, color: blue)), pw.Text(value)]));

  static Future<void> previewBudget(BuildContext context, Budget b) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Orçamento em PDF')), body: PdfPreview(build: (_) => buildBudget(b), canChangePageFormat: false, canChangeOrientation: false, pdfFileName: 'Orcamento_DRYNIEL_${b.client.replaceAll(' ', '_')}.pdf'))));
  }
}
